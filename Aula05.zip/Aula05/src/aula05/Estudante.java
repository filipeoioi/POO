package aula05;

public class Estudante {
    private String nome;
    private int ra;
    public int idade;
    
    public Estudante(){
        this.nome = "";
        this.ra = 0;
        this.idade = 0;
    }
    
    public Estudante(String nome, int ra, int idade){
        this.nome = nome;
        this.ra = ra;
        this.idade = idade;
    }
    public void setNome(){
        this.nome="";
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    
    @Override
    public String toString(){
        return "Nome:" + this.nome + " RA:" + this.ra;
    }
    
}
