/*
   DONE1: Classe Estudante: Crie um construtor sobrecarregado que
           aceite 2 (dois) argumentos diferentes.
   DONE2: Classe Estudante: Crie 2 (dois) métodos sobrecarregados que modificam
           o atributo nome.
   DONE3: Classe Estudante: Utilize o método toString para imprimir o
           estado de execução do objeto.
   TODO4: Classe Estudante: Crie um atributo idade de acesso public.
           Ilustre a chamada desse atributo na classe Principal.
   TODO5: Classe Estudante: Crie um atributo endereco de acesso private.
           Ilustre a chamada desse atributo na classe Principal.
*/
package aula05;

public class Principal {

    public Principal(){
        
        
    }

    public static void main(String[] args) {
        Estudante aluno1 = new Estudante("Filipe", 2320622);
        System.out.println(aluno1);
        Estudante aluno2 = new Estudante("Filipe", 2320622, 21);
        System.out.println(aluno2);
    }
}
