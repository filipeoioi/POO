/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula06ex3;

import java.util.ArrayList;

/**
 *
 * @author a2320622
 */
public class Banco {
    private ArrayList<Cliente> lista1; //lista dinamica
    private String nome;
    
    public void add(Cliente cliente){
        lista1.add(cliente);
    }
    public void del(Cliente cliente){
        lista1.remove(cliente);
    }
    
}
