package ex09;

/*
Exercicio 09
Autor(es): Filipe Augusto Parreira Almeida
Data: 15/06/2023
*/

public interface Genero {
    public abstract String getDescricao();
}
