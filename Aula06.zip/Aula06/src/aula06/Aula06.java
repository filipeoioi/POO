/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula06;

import java.util.ArrayList;

/**
 *
 * @author a2320622
 */
public class Aula06 {

    public Aula06(){
        Curso poo = new Curso("POO");
        Estudante estudante1 = new Estudante("Filipe");
        Estudante estudante2 = new Estudante("João");
        poo.add(estudante1);
        poo.add(estudante2);
        ArrayList<Estudante> lista = poo.getEstudantes();
        System.out.println("Tam lista: " + lista.size());
        Iterator item = lista.iterator();
        while
        
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new Aula06();
        
    }
    
}
