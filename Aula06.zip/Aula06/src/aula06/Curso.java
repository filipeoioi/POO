/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula06;

import java.util.ArrayList;

/**
 *
 * @author a2320622
 */
public class Curso {
    private String nome;
    private ArrayList<Estudante> lista1;//Lista dinamica
    private Estudante [] lista2; //Lista estatica
    
    public Curso(String nome){
        this.nome = nome;
        lista1 = new ArrayList<>();
    }
    public void add(Estudante estudante){
        lista1.add(estudante);
        //lista2[0] = estudante;
    }
    public ArrayList<Estudante> getEstudantes(){
        return this.lista1;
    }
}
