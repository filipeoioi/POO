/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula06;

/**
 *
 * @author a2320622
 */
public class Estudante {
    private String nome;
    
    public Estudante(String nome){
        this.nome = nome;
    }
    
}
