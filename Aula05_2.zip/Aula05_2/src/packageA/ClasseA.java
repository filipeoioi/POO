package packageA;

public class ClasseA {
    public ClasseA(){
        Principal p = new Principal();
        System.out.println(p.primeiro);
        System.out.println(p.segundo);
        System.out.println(p.terceiro);
        
    }
}
