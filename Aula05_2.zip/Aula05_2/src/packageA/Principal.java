package packageA;

public class Principal {
    //Todas as classes tem acesso
    public int primeiro;
    //package-private
    int segundo;
    //package-private e pelos filhos 
    protected int terceiro;
    //somente pela classe 
    private int quarto;
    
    public static void main(String[] args) {
        // TODO code application logic here
        
    }
    
}
