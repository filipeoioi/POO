package packageB;
import packageA.Principal;


public class ClasseB extends Principal{
    public ClasseB(){
        Principal p = new Principal();
        System.out.println(p.primeiro);
        //System.out.println(p.segundo);
        System.out.println(terceiro);
        //System.out.println(quarto);
    }
}
