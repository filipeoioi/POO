package aula04;

public class Principal {
    public Principal() {

            Calculadora nokia = new Calculadora();
            nokia.setMarca("Nokia");
            System.out.println(  nokia.getMarca() );

      }


      public static void main(String [ ] args){
            
            Principal obj = new Principal();
      }
}
