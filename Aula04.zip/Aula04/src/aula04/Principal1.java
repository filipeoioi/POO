package aula04;
import javax.swing.JOptionPane;

public class Principal1 {
    public Principal1() {

            String num1 = JOptionPane.showInputDialog(null, "Digite o numero1: ");
            float numero1 = Float.parseFloat(num1);
            
            String num2 = JOptionPane.showInputDialog(null,"Digite o numero2: ");
            float numero2 = Float.parseFloat(num2);
            
            JOptionPane.showMessageDialog(null, (numero1 + numero2), "Resultado:", JOptionPane.OK_OPTION);
    }


      public static void main(String [ ] args){
            
            Principal1 obj = new Principal1();
            System.exit(0);
            
      }
}
