package aula04;

public class Calculadora {

         private String marca;

         //Metodos assessores
         public String getMarca(){
               return this.marca;
         }
         //Metodos mutadores
        public void setMarca(String marca){
              this.marca = marca;
         }

}



