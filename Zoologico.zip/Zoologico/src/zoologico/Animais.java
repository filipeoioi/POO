package zoologico;

//     Sapo é um Animal
//(Subclasse)    (Superclasse)
public class Animais {
    
    public String nome;
    public float tamanho;
    
    public Animais(String nome, float tamanho){
        this.nome = nome;
        this.tamanho = tamanho;
    }
}
