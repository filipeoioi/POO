package zoologico;

public class Zoo {
    public Zoo(){
        Sapo sapo = new Sapo("Sapo", "Muitas", 0.47f);
        Leao leao = new Leao("Leão", "Muitos", 2.53f);
        System.out.println(sapo);
        System.out.println(leao);
    }
    public static void main(String[] args) {
        new Zoo();
    }
    
}
