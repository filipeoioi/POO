package zoologico;

public class Leao extends Animais{
    public String pelos;
    
    public Leao(String nome, String pelos, float tamanho){
        super(nome, tamanho);
        this.pelos = pelos;
    }
    
    @Override
    public String toString(){
        return "Quantidade de pelos: " + this.pelos + " | Nome: " + 
                this.nome + " | Tamanho: " + this.tamanho + " m";
    }
}
