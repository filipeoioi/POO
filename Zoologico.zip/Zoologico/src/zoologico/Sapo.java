package zoologico;

public class Sapo extends Animais{
    private String escamas;
    
    public Sapo(String nome, String escamas, float tamanho){
        super(nome, tamanho);
        this.escamas = escamas;
    }
    @Override
    public String toString(){
        return "Quantidade de escamas: " + this.escamas + " | Nome: " + 
                this.nome + " | Tamanho: " + this.tamanho + " m";
    }
}
