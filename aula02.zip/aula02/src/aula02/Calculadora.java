/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula02;

public class Calculadora {
    //Variaveis de instancia 
    public int campo1; //Atributo
    public int campo2; //Atributo
    public int op; //Atributo
    public String marca;//Atributo 
    public String cor;//Atributo 
    public Float tam;//Atributo 
    public String resultado;
    
    //Construtor padrão(NÃO É MÉTODO)
    public Calculadora(){
        this.campo1 = 0;
        this.campo2 = 0;
        this.op = 1; //1 = soma 
        this.cor = "";
        this.marca = "";
        this.tam = 1.23f;
        
    }
    
    
    //Metodos Mutadores 
    public void setMarca(String marca){
        this.marca = marca;
    }
    public void setCampo1(int campo1){
        this.campo1 = campo1;
    }
    public void setCampo2(int campo2){
        this.campo2 = campo2;
    }
    public void setOperacao(int op){
        this.op = op;
    }
    public void setTam(Float tam){
        this.tam = tam;
    }
    public void setCor(String cor){
        this.cor = cor;
    }
    
    
    //Metodos Acessores  
    public String getMarca(){
        return this.marca;
    }
    
    public int getCampo1(){
        return campo1;
    }
    
    public int getCampo2(){
        return campo2;
    }
    
    public Float getTam(){
        return this.tam;
    }
    
    public String getCor(){
        return this.cor;
    }
    
    public int getOp(){
        return this.op;
    }
   
    public void imprimir(){
        
          
          switch( op ){
                  case 1: {
                      resultado = campo1 + campo2;
                      break;
                  }
                  case 2: {
                       resultado = campo1 - campo2;
                       break;
                   }
                  default:
                  break;
          }//fim switch          

          System.out.println("Resultado: " + resultado);
    
        }
        
    
        public String toString(){
        
            return "Campo1: " + this.getCampo1() + "\n"+ 
                    "Campo2: " + this.getCampo2() + "\n" +
                    "Operação: " + this.getOp() + "\n" +
                    "Marca: " + this.getMarca() + "\n" +
                    "Cor: " + this.getCor() + "\n" +
                    "Tamanho: " + this.getTam() + "\n" +
                    "Resultado: " + resultado + "\n";
        }
        
    }
