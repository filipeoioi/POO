/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula02;

public class Principal{

    public static void main(String args[]){
        Calculadora calculadora = new Calculadora();
        Calculadora calculadora1 = new Calculadora();
        Calculadora calculadora2 = new Calculadora();
        
        calculadora.setCampo1(5);
        calculadora.setCampo2(2);
        calculadora.setOperacao(2);
        calculadora.setCor("Preta");
        calculadora.setMarca("HP");
        calculadora.setTam(5.64f);
        
        calculadora1.setCampo1(5);
        calculadora1.setCampo2(2);
        calculadora1.setOperacao(1);
        calculadora1.setCor("Cinza");
        calculadora1.setMarca("Sony");
        calculadora1.setTam(6.21f);
        
        calculadora2.setCampo1(10);
        calculadora2.setCampo2(10);
        calculadora2.setOperacao(1);
        calculadora2.setCor("Azul");
        calculadora2.setMarca("Philco");
        calculadora2.setTam(10.5f);
        
        System.out.println(calculadora.toString());
        System.out.println(calculadora1.toString());


        /*
        calculadora.setCampo1(10);
        calculadora.setCampo2(20);
        calculadora.setOperacao(2);
        int campo1 = calculadora.getCampo1();
        System.out.println(campo1);
        
        String marca = new String("Sony");
        //Wrapper: encapsuladora de tipo
        calculadora.setMarca(marca);
        calculadora.setTam(1.23f);
        calculadora.setCor("azul");
        
        
        Calculadora hp = new Calculadora();
        hp.setCampo1(20);
        System.out.println();
        */
        
        

        
    }
    
    
}

