package floricultura;

public class Floricultura {
    //Variaveis de Instancia
    public String nome;
    public String tipo;
    public String cor;
    public Float preco;
    
    //Construtor
    public Floricultura(){
        this.cor = "";
        this.nome = "";
        this.tipo = "";
        this.preco = 0.00f;
    }
    
    //Métodos Mutadores
    public void setCor(String cor){
        this.cor = cor;
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    public void setTipo(String tipo){
        this.tipo = tipo;
    }
    public void setPrice(Float preco){
        this.preco = preco;
    }
    
    //Metodos Acessores
    public String getNome(){
        return this.nome;
    }
    
    public String getTipo(){
        return this.tipo;
    }
    
    public String getCor(){
        return this.cor;
    }
    
    public Float getPrice(){
        return this.preco;
    }
    
    
    public String toString(){
        return "Nome: " + this.getNome() + "\n" +
                "Tipo: " + this.getTipo() + "\n" +
                "Cor: " + this.getCor() + "\n" +
                "Preço: R$" + this.getPrice() + "\n";
    }
}
