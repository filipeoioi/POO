/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package floricultura;
import javax.swing.JOptionPane;

public class Principal {
    
    public static void main(String[] args) {
        Floricultura flor = new Floricultura();
        flor.setNome("Margarida");
        flor.setCor("Amarela");
        flor.setTipo("Flor Margarida");
        flor.setPrice(5.99f);
        JOptionPane.showMessageDialog(null, flor.toString(), "Floricultura",JOptionPane.OK_OPTION);
        

    }
}
